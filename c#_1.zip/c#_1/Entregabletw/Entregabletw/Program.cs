﻿Console.WriteLine("Ingrese un número: ");
        int numero;
        if (!int.TryParse(Console.ReadLine(), out numero))
        {
            Console.WriteLine("Entrada inválida. Por favor, ingrese un número entero válido.");
            return;
        }

        if (numero % 5 == 0 && numero % 3 != 0 && numero % 2 != 0)
        {
            Console.WriteLine($"{numero} es un número especial.");
        }
        else
        {
            Console.WriteLine($"{numero} no es un número especial.");
        }