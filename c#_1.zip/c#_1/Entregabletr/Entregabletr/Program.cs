﻿Console.WriteLine("Ingrese su edad:");
        int edad;
        if (!int.TryParse(Console.ReadLine(), out edad))
        {
            Console.WriteLine("Entrada inválida. Por favor, ingrese un número entero válido para la edad.");
            return;
        }

        int dias = edad * 365;
        int semanas = edad * 52;

        Console.WriteLine($"Han pasado {dias} días desde que naciste.");
        Console.WriteLine($"Han pasado {semanas} semanas desde que naciste.");

        // Inicio de sesión
        string usuarioCorrecto = "admin";
        string contraseñaCorrecta = "rappi";
        int intentos = 3;

        while (intentos > 0)
        {
            Console.WriteLine("Ingrese el usuario: ");
            string usuarioIngresado = Console.ReadLine();

            Console.WriteLine("Ingrese contraseña: ");
            string contraseñaIngresada = Console.ReadLine();

            if (usuarioIngresado == usuarioCorrecto && contraseñaIngresada == contraseñaCorrecta)
            {
                Console.WriteLine("¡Acceso permitido!");
                break;
            }
            else
            {
                intentos--;
                if (intentos > 0)
                {
                    Console.WriteLine($"Acceso denegado. Te quedan {intentos} intentos.");
                }
                else
                {
                    Console.WriteLine("Acceso denegado. Se han agotado los intentos.");
                }
            }
        }