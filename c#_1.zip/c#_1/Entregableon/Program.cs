﻿
    Console.WriteLine("Ingrese el primer número: ");
    double x = double.Parse(Console.ReadLine());
        
    Console.WriteLine("Ingrese el segundo número: ");
        double y = double.Parse(Console.ReadLine());
        
    Console.WriteLine("Ingrese el operador (+, -, *, /):");
    char operador = char.Parse(Console.ReadLine());

    double resultado = 0;

    switch (operador)
        {
        case '+':
                resultado = x + y;
                Console.WriteLine("La suma de los valores es: " + resultado);
                break;
        case '-':
                resultado = x - y;
                Console.WriteLine("La resta de los valores es: " + resultado);
                break;
        case '*':
                resultado = x * y;
                Console.WriteLine("La multiplicación de los valores es: " + resultado);
                break;
        case '/':
            if (y == 0)
                {
                    Console.WriteLine("No se puede dividir por cero.");
                }
            else
                {
                    resultado = x / y;
                    Console.WriteLine("La división de los valores es: " + resultado);
                }
            break;
            default:
                Console.WriteLine("Operador no válido.");
                break;
        }
  


