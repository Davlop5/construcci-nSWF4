﻿using System;

class Pokemonplay
{    
    public string Nombre { get; set; }
    public string Tipo { get; set; }
    public int Salud { get; set; }
    public int[] Ataques { get; set; } = new int[3];
    public int[] Defensas { get; set; } = new int[2];

    public int Atacar()
    {
        Random random = new Random();
        int ataqueSeleccionado = random.Next(0, 3);
        double multiplicador = random.NextDouble() switch
        {
            var x when x < 0.3 => 1.0,
            var x when x < 0.6 => 0.5,
            _ => 1.5
        };

        return (int)(Ataques[ataqueSeleccionado] * multiplicador);
    }

    public int Defender()
    {
        Random random = new Random();
        int defensaSeleccionada = random.Next(0, 2);
        double multiplicador = random.NextDouble() switch
        {
            var x when x < 0.5 => 1.0,
            _ => 0.5
        };

        return (int)(Defensas[defensaSeleccionada] * multiplicador);
    }
}

class Program
{
    static void Main()
    {
        // Crear a Dunsparce
        Pokemonplay dunsparce = new Pokemonplay
        {
            Nombre = "Dunsparce",
            Tipo = "Normal",
            Salud = 100,
            Ataques = new int[] { 40, 35, 30 },
            Defensas = new int[] { 25, 30 }
        };

        // Crear a Gourgeist
        Pokemonplay gourgeist = new Pokemonplay
        {
            Nombre = "Gourgeist",
            Tipo = "Fantasma/Planta",
            Salud = 100,
            Ataques = new int[] { 38, 32, 37 },
            Defensas = new int[] { 28, 22 }
        };

        // Simular los combates durante 3 turnos
        for (int turno = 1; turno <= 3; turno++)
        {
            int ataqueDunsparce = dunsparce.Atacar();
            int defensaGourgeist = gourgeist.Defender();
            int danoDunsparce = Math.Max(0, ataqueDunsparce - defensaGourgeist);
            gourgeist.Salud -= danoDunsparce;

            int ataqueGourgeist = gourgeist.Atacar();
            int defensaDunsparce = dunsparce.Defender();
            int danoGourgeist = Math.Max(0, ataqueGourgeist - defensaDunsparce);
            dunsparce.Salud -= danoGourgeist;

            Console.WriteLine("Turno " + turno + ":");
            Console.WriteLine(dunsparce.Nombre + " ataca a " + gourgeist.Nombre + " y le hace " + danoDunsparce + " puntos de daño.");
            Console.WriteLine(gourgeist.Nombre + " ataca a " + dunsparce.Nombre + " y le hace " + danoGourgeist + " puntos de daño.");
        }

        // Determinar el ganador o si hay empate
        if (dunsparce.Salud > gourgeist.Salud)
        {
            Console.WriteLine(dunsparce.Nombre + " gana.");
            Console.WriteLine(dunsparce.Nombre + " es el campeón del ring.");
        }            
        else if (gourgeist.Salud > dunsparce.Salud)
            Console.WriteLine(gourgeist.Nombre + " gana.");
        else
            Console.WriteLine("¡Empate!");

        Console.ReadLine();
    }
}
